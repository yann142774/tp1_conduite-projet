#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define N 3
#define M 4

void afficher_matrice(int mat[N][M]){
	int i,j = 0;
	for(i=0;i<N;i++){
		for(j=0;j<M;j++){
			printf("%i ", mat[i][j]);
		}
		printf("\n");	
	}
}

int norme_ligne(int mat[N][M]){
	int j = 0;
	int i = 0;
	int somme1 = 0;
	int somme2 = 0;
	for(i=0;i<N;i++){ 
			for(j=0;j<M;j++){
				somme2 += abs(mat[i][j]);
			}
		if(somme2>somme1){
			somme1=somme2;	
		}
	somme2=0;		
	}	
	return somme1;
}

int norme_colonne(int mat[N][M]){
	int j = 0;
	int i = 0;
	int somme1 = 0;
	int somme2 = 0;
	for(j=0;j<M;j++){ 
			for(i=0;i<N;i++){
				somme2 += abs(mat[i][j]);
			}
		if(somme2>somme1){
			somme1=somme2	;
		}
	somme2=0;		
	}	
	return somme1;
}

int main(){
	int matrice[N][M];
	int i = 0;
	int valeur = 0;
	int j = 0;
	int norme_lig = 0;
	int norme_col = 0;
	char nomfic [20];
	FILE * fic;
	printf("Donnez le nom du fichier \n");
	scanf("%s", nomfic);
	
	fic = fopen(nomfic ,"r");
	
	for(i=0;i<N;i++){ 
			for(j=0;j<M;j++){
				fscanf(fic,"%i", &matrice[i][j]);
			}
	}		
	afficher_matrice(matrice);
	norme_lig = norme_ligne(matrice);
	norme_col = norme_colonne(matrice);
	printf("\n Norme ligne : %i \n", norme_lig);
	printf("Norme colonne : %i \n", norme_col);
	
	fclose(fic);
	return 0;
}	
	
	
			
		